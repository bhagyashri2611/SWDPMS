import { Component } from '@angular/core';

@Component({
  selector: 'app-cumulativehighwayreport',
  templateUrl: './cumulativehighwayreport.component.html',
  styleUrls: ['./cumulativehighwayreport.component.scss']
})
export class CumulativehighwayreportComponent {

}
