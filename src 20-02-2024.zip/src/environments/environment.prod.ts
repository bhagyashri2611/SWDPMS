export const environment = {
  production: true,
  // baseUrl: 'https://swd.mcgm.gov.in/internaldashapi',
  baseUrl: 'http://localhost:3000/api/',
  // baseUrl: 'http://localhost:13984',
  // baseUrl: 'http://localhost/swdapi'
  // baseUrl: 'https://swm.mcgm.gov.in:8081/api'
  //  Client_ID_FB = 1118445942135621,
};
