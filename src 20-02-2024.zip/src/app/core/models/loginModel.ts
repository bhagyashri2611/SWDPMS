export class LoginModel {
  // public Id: number = 0;

  // public User_Name: string = '';
  // public Role_ID: number = 0;
  // public User_Pass: string = '';
  // public Confirm_Pass: string = '';

  public UserId: number = 0;
  public userName: string = '';
  public password: string = '';
  public Email_Id: string = '';
  public Role: number = 0;
  public WorkCode: string = '';
  public ParentCode: string = '';
  public Name: string = '';
  public VersionCode: Number = 0;
  public VersionName: string = '';

  public ServerName: string = '';

  public CreatedBy: string = '';
  public CreatedDate: string = '';
  public modifiedBy: string = '';
  public modifiedDate: string = '';

  public viewName = 'Login';
}
