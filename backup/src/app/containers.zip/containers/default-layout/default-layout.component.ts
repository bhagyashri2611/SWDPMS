import { Component } from '@angular/core';
import { navItems, navItemsUser } from './_nav';

@Component({
  selector: 'app-dashboard',
  templateUrl: './default-layout.component.html',
})
export class DefaultLayoutComponent {
  public navItems;
  public perfectScrollbarConfig = {
  suppressScrollX: true,
};

constructor() { 
  let UserRole = sessionStorage.getItem("Role");
  if(Number(UserRole) == 1) {
    this.navItems=navItems
  }
  if(Number(UserRole) == 5 || Number(UserRole) == 6) {
    this.navItems=navItemsUser
  }
}
}
