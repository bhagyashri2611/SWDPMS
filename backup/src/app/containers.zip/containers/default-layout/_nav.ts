import { INavData } from '@coreui/angular';

export const navItems: INavData[] = [
  {
    name: 'Dashboard',
    url: '/dashboard',
    iconComponent: { name: 'cil-speedometer' },
    badge: {
      color: 'info',
      text: 'NEW'
    }
  },
  // {
  //   name: 'Reports',
  //   title: true
  // },
  {
    name: 'Reports',
    url: '/reports',
   
    // iconComponent: { name: 'cil-puzzle' },
  },

  {
    name: 'Export to Excel',
    url: '/reports/exporttoexcel'
  },
  {
    name: 'Silt Quantity',
    url: '/reports/slitqualitity'
  },
  {
    name: 'Cumulative Major Nallah Report',
    url: '/reports/CumulativeMajorNallahReport'
  },
  {
    name: 'Cumulative Minor Nallah Report',
    url: '/reports/CumulativeMinorNallahReport' 
  },
    
  {
    name: 'Workcode wise Report',
    url: '/reports/WorkcodeWiseReport'
  },
  {
    name: 'Major Nalla Progress Report',
    
    children: [
      {
        name: 'Pre-Monsoon',
        url: '/reports/MajorProgressPreMansoonReport'
      },
      {
        name: 'During-Monsoon',
        url: '/reports/MajorProgressDuringMansoonReport'
      }
    ]
  },
  {
    name: 'Minor Nalla Progress Report',
    children: [
      {
        name: 'Pre-Monsoon',
        url: '/reports/MinorProgressPreMansoonReport'
      },
      {
        name: 'During-Monsoon',
        url: '/reports/MinorProgressDuringMansoonReport'
      }
    ]
  },
  {
    name: 'Billable Silt Report',
    url: '/reports/BillableSiltReport'
  },
  {
    name: 'Tripwise Silt Report',
    url: '/reports/TripwiseSiltReport'
  },
  {
    name: 'View Site Vehicle Image',
    url: '/reports/ViewSiteVehicleImage'
  },
  {
    name: 'View Nallah Loading Videos',
    url: '/reports/ViewNallahLoadingVideos'
  },













];


export const navItemsUser: INavData[] = [
  {
    name: 'Dashboard',
    url: '/dashboard',
    iconComponent: { name: 'cil-speedometer' },
    badge: {
      color: 'info',
      text: 'NEW'
    }
  },  
  {
    name: 'Billable Silt Report',
    url: '/reports/BillableSiltReport'
  },
  {
    name: 'Tripwise Silt Report',
    url: '/reports/TripwiseSiltReport'
  },
  {
    name: 'View Site Vehicle Image',
    url: '/reports/ViewSiteVehicleImage'
  },
  {
    name: 'View Nallah Loading Videos',
    url: '/reports/ViewNallahLoadingVideos'
  },
];