export const environment = {
  production: true,
  // baseUrl: 'https://roads.mcgm.gov.in/internaldashapi',
  baseUrl: 'https://roads.mcgm.gov.in:3000/api/',
  smsUrl: 'http://localhost:1027/service.svc',
  // baseUrl: 'http://localhost:13984',
  // baseUrl: 'http://localhost/swdapi'
  // baseUrl: 'https://swm.mcgm.gov.in:8081/api'
  //  Client_ID_FB = 1118445942135621,
};
